package model

class FacturaProvider {
    companion object {
        val factura = listOf<FacturaModel>(

        )
    }
}