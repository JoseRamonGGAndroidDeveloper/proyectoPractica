package model

data class FacturaModel(val descEstado:String, val importeOrdenacion:String, val fecha:String)
