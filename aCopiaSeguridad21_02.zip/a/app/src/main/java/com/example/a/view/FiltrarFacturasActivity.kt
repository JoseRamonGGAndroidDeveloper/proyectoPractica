package com.example.a.view

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.a.R
import java.util.Calendar

class FiltrarFacturasActivity : AppCompatActivity() {


    val calendario = Calendar.getInstance()
    val ano = calendario.get(Calendar.YEAR)
    val mes = calendario.get(Calendar.MONTH)
    val dia = calendario.get(Calendar.DAY_OF_MONTH)

    var booleanFechaDesdePulsada = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_filtrar_facturas)

        //Selector fechaDesde
        findViewById<Button>(R.id.fechaBotonDesde).setOnClickListener() {

            booleanFechaDesdePulsada = true

            val dPdDesde = DatePickerDialog(this, DatePickerDialog.OnDateSetListener{view, mAno, mMes, mDia ->
                findViewById<Button>(R.id.fechaBotonDesde).text = ""+mDia+"/"+mMes+"/"+mAno
            },ano,mes+1,dia)
            dPdDesde.show()

        }

        //Selector fechaHasta
        if (booleanFechaDesdePulsada){
            findViewById<Button>(R.id.fechaBotonHasta).setOnClickListener() {
                val dPdHasta = DatePickerDialog(this, DatePickerDialog.OnDateSetListener{view, mAno, mMes, mDia ->

                    findViewById<Button>(R.id.fechaBotonHasta).text = ""+mDia+"/"+mMes+"/"+mAno

                },ano,mes+1,dia)
                dPdHasta.show()
            }
        }
        else {
            findViewById<Button>(R.id.fechaBotonHasta).setOnClickListener() {
                showFechaDesdeError()
            }
        }




        //Cerrar pestaña sin guardar
        findViewById<ImageButton>(R.id.closeButton).setOnClickListener() {
            finish()
        }
    }

        fun showFechaDesdeError(){
            Toast.makeText(this, "Para seleccionar la fecha de 'Hasta' primero debe seleccionar la fecha 'Desde'", Toast.LENGTH_SHORT).show()
        }
}
