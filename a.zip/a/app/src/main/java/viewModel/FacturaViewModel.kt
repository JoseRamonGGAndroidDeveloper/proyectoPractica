package viewModel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class FacturaViewModel : ViewModel(){

    val facturaModel = MutableLiveData<FacturaViewModel>()
}