package view

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import com.example.a.R
import com.example.a.databinding.ActivityMainBinding
import viewModel.FacturaViewModel

class MainActivity : AppCompatActivity() {

    private lateinit var mainBinding: ActivityMainBinding

    private val facturaViewModel: FacturaViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mainBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(mainBinding.root)

        facturaViewModel.facturaModel.observe(this, Observer {

        })


        //Boton para ir a la acitivty de filtrar facturas
        mainBinding.adio.setOnClickListener() {
            val intent = Intent(this, FiltrarFacturasActivity::class.java)
            startActivity(intent)
        }


    }
}