package view

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.a.R
import com.example.a.databinding.ActivityFiltrarFacturasBinding
import com.example.a.databinding.ActivityMainBinding
import viewModel.FacturaViewModel
import java.util.Calendar

class FiltrarFacturasActivity : AppCompatActivity() {


    val calendario = Calendar.getInstance()
    val ano = calendario.get(Calendar.YEAR)
    val mes = calendario.get(Calendar.MONTH)
    val dia = calendario.get(Calendar.DAY_OF_MONTH)

    //filtrarBinding
    private lateinit var filtrarBinding: ActivityFiltrarFacturasBinding



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        filtrarBinding = ActivityFiltrarFacturasBinding.inflate(layoutInflater)
        setContentView(filtrarBinding.root)

        //Selector fechaDesde
        filtrarBinding.fechaBotonDesde.setOnClickListener() {

            val dPdDesde = DatePickerDialog(
                this,
                DatePickerDialog.OnDateSetListener { view, mAno, mMes, mDia ->
                    filtrarBinding.fechaBotonDesde.text =
                        "" + mDia + "/" + mMes + "/" + mAno
                },
                ano,
                mes + 1,
                dia
            )
            dPdDesde.show()
        }

        //Selector fechaHasta

        filtrarBinding.fechaBotonHasta.setOnClickListener() {
            val dPdHasta = DatePickerDialog(
                this,
                DatePickerDialog.OnDateSetListener { view, mAno, mMes, mDia ->

                    filtrarBinding.fechaBotonHasta.text =
                        "" + mDia + "/" + mMes + "/" + mAno

                },
                ano,
                mes + 1,
                dia
            )
            dPdHasta.show()
        }

        //Cerrar pestaña sin guardar
        filtrarBinding.closeButton.setOnClickListener() {
            finish()
        }
    }

    fun showFechaDesdeError() {
        Toast.makeText(
            this,
            "Para seleccionar la fecha de 'Hasta' primero debe seleccionar la fecha 'Desde'",
            Toast.LENGTH_SHORT
        ).show()
    }

    fun verificarCompatibilidad( dDia:String, dMes:String, dAno:String, hDia:String, hMes:String, hAno:String){
        val fechaDesde = dDia+"/"+dMes+"/"+dAno
        val fechaHasta = hDia+"/"+hMes+"/"+hAno


    }

}




